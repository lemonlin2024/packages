
# This file is auto-generated with the version information during setup.py installation.

__version__ = '1.9.0'
