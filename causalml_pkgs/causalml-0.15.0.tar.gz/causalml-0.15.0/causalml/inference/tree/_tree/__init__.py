"""
This part of tree structures definition was initially borrowed from
https://github.com/scikit-learn/scikit-learn/tree/1.0.2/sklearn/tree
"""
